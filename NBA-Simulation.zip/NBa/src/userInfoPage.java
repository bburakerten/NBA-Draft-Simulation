import java.awt.Frame;
import javax.swing.JLabel;
import javax.swing.JFrame;

public class userInfoPage {
	public static void main(String[] args) {
		
	}

	public static void showwindow() {
		JFrame frame = new JFrame ("WINDOW 1");
		frame. setBounds (100,100,100, 100);
		frame. setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame. getContentPane(). setLayout (null);
		frame. setVisible(true);
}

}
